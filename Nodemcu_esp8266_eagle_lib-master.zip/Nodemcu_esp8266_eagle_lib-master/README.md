# Nodemcu esp8266 dev board

This is a simple nodemcu library for esp8266