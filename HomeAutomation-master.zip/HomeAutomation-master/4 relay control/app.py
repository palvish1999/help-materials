from flask import Flask, render_template, request
import socket
import threading

app = Flask(__name__)

ESP8266_HOST = '192.168.1.185'  # Replace with the ESP8266's IP address
ESP8266_PORT = 80  # Same port as defined in the ESP8266 code
RASPBERRY_PI_PORT = 12345  # Choose a port for the Raspberry Pi server

def raspberry_pi_server():
    # Raspberry Pi server setup
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as raspberry_pi_server_socket:
        raspberry_pi_server_socket.bind(('0.0.0.0', RASPBERRY_PI_PORT))
        raspberry_pi_server_socket.listen(1)
        print("Raspberry Pi Server started")

        # Raspberry Pi server loop
        while True:
            client_conn, client_addr = raspberry_pi_server_socket.accept()
            with client_conn:
                print('Connected by', client_addr)
                while True:
                    data = client_conn.recv(1024)
                    if not data:
                        break
                    print('Received from ESP8266 client:', data.decode())

def raspberry_pi_client(command):
    # Raspberry Pi client setup
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as raspberry_pi_client_socket:
        raspberry_pi_client_socket.connect((ESP8266_HOST, ESP8266_PORT))
        print("Connected to ESP8266")
       # command = str(command)
        # Send command to ESP8266
        raspberry_pi_client_socket.sendall(command.encode())
        print("Sent to ESP8266:", command)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/control', methods=['POST'])
def control():
    command = request.form['command']
    threading.Thread(target=raspberry_pi_client, args=(command,)).start()
    return 'Command sent: ' + command

def main():
    # Create a thread for the server
    server_thread = threading.Thread(target=raspberry_pi_server)
    server_thread.start()

    # Run Flask app
    app.run(debug=True, host='0.0.0.0')

if __name__ == "__main__":
    main()
