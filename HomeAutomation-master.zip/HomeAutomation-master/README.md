IOT BASED HOME AUTOMATION SYSTEM USING MOBILE APP

The project is base upon IOT technology to control the water pump remotely. This technology is booming across the world and dominating many aspects in tech field.

Working:

The input is given through mobile app and web app to switch on/off the pump remotely. As IOT technology we Monitor various data like Pump status , temp , flow also.

Hardware Used:

1)WiFi module Esp32/8266

2)Relay

3)Temp sensor

4)Flow sensor

5)Power supply 

6)Connecting wires


Advantages:

1)Energy saving

2)Water saving

3)Capital saving

4)Time saving

Application:

1)Remotely control 

2)Home automation 

3)Smart homes 

4)Smart agriculture

5)Smart energy management and monitoring

6)Weather forecasting

![image](https://github.com/mabzone/HomeAutomation/assets/160022225/fed57a26-90c8-4b9e-91ad-cd6b12ccc7e7)

Steps to start and run project:

1)Open Arduino IDE application

2)Go to file section and open project

3)Enter name or search IOT based pump control in documents

4)Open project then hit compile button

5)After compilation hit upload button 

6)At last it will take some time to upload code in controller 

Git hub repo link :https://github.com/mabzone/HomeAutomation

Wiring Diagram :
![image](https://github.com/mabzone/HomeAutomation/assets/160022225/79cefa20-18a9-435c-a55b-609042c52567)
