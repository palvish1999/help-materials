SMART PUMP CONTROL SYSTEM USING LORA COMMUNICATION AND MOBILE APP

This project is developed to control motor which is installed in fields far from home using Lora communication.

Working:

Firstly, it controlled via mobile app. There are some buttons on/off present in mobile app when button is on it transmit signal to controller and further controller did Radio frequency 865mz to send and receive signal to on/off the pump. At receiver end it decode the message and through controller at receiver side perform high/low.

Hardware used:

1)Two Lora modules Sx1278

2)Two microcontrollers at tx and rx end

3)Power adapters

4)Digital relays

TX part:

![image](https://github.com/mabzone/SmartPumpControl_Lora/assets/160022225/ab1840b9-9f61-4528-80b6-0555094bfaa1)


Rx part:

![image](https://github.com/mabzone/SmartPumpControl_Lora/assets/160022225/52904380-eb47-43d6-991b-dd4cd591d6a1)


Advantages:

1)Energy saving

2)Water saving

3)Time saving

4)Remote control from any where

5)Cost effective 

6)Resource saving

Application:

1)Further used for Smart Agriculture management system 

2)Smart Agriculture Monitoring system

3)Smart Energy monitoring system 

![image](https://github.com/mabzone/SmartPumpControl_Lora/assets/160022225/dee88dc9-bfa4-452f-b558-ae4ec57adca6)

