Object detection using openCV

The main motive to build this project is use deep leaning or artificial intelligence because this technology is currently dominating market in every aspect.

Working;

Firstly, this project images or video feed take as input which goes under image processing
 techniques where open cv library used for image processing. 

In this part we have to train data using data driven models where we put numerous images and train model to get high accuracy.
There are many tools where we can train data models for object detection.

The whole project is working with python language and output is shown below.

![image](https://github.com/mabzone/ObjectDetection/assets/160022225/76e916f2-7310-4949-ad8b-3f4daee1afb4)


![image](https://github.com/mabzone/ObjectDetection/assets/160022225/f57d2a93-e7d6-41fe-ad90-877d47c5394e)


Application;

1)Agriculture sector 

2)Defense sector

3)Traffic management

4)Retails and hospitality

5)Automobile sector

6)Surveillance and survey

7)Mapping using drone

8)Many more endless

Github Link :https://github.com/mabzone/ObjectDetection
